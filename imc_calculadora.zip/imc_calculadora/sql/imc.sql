CREATE DATABASE IF NOT EXISTS imc_calculadora;
USE imc_calculadora;

CREATE TABLE IF NOT EXISTS registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    edad INT NOT NULL,
    sexo VARCHAR(10) NOT NULL,
    peso FLOAT NOT NULL,
    altura FLOAT NOT NULL,
    imc FLOAT NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    fecha DATETIME NOT NULL
);
